# Wreal X — Official Artist Website V1

This package contains the first working Wreal X website concept based on the supplied inspiration and links.

## Included

- Full responsive Wreal X homepage
- Supplied background photo
- Three supplied YouTube videos embedded
- YouTube view-count fields wired to a backend API
- YouTube channel subscriber/view/video-count fields wired to a backend API
- Three SoundCloud releases with supplied cover art
- SoundCloud playback-count aggregation wired to the backend when SoundCloud API credentials are configured
- Tiny streaming-platform icons inside each song card
- Apple Music / TIDAL / Spotify / YouTube / SoundCloud / Audiomack destinations
- Social links with real service icons
- Soundplate smart-link section for "Time"
- Tawk.to widget
- Beacons email form, triggered on the visitor's first scroll per browser session
- Payhip embeds for the two supplied products
- Cookie allow/reject banner that disappears immediately and stores the choice
- Scroll reveal effects, responsive cards and back-to-top button

## Run locally

1. Copy `.env.example` to `.env`.
2. Add API credentials.
3. Install Node.js 18+.
4. Run:
   npm install
   npm start
5. Open http://localhost:3000

## Live statistics

The frontend intentionally does not scrape or invent follower/view numbers.

### YouTube
The backend uses the official YouTube Data API. Add:
- `YOUTUBE_API_KEY`
- `YOUTUBE_CHANNEL_ID`

The supplied video IDs are already configured:
- swCF5DMFquE
- T59z8NQ3OMA
- 2H3Ei5EPkFc

### SoundCloud
The backend uses the official SoundCloud public API with client-credentials authentication. Add:
- `SOUNDCLOUD_CLIENT_ID`
- `SOUNDCLOUD_CLIENT_SECRET`

The supplied SoundCloud tracks are already configured:
- /wrealx/monalisa
- /wrealx/photo
- /wrealx/hurry-up

### Other social follower counts
Instagram, TikTok, Facebook and X should be added through their current approved APIs or an authorized analytics provider. A profile URL/iframe alone does not expose a reliable follower count to JavaScript.

## Production recommendation

Do not put API secrets in `index.html`. Keep them server-side in environment variables. Put the site behind HTTPS and add caching/rate limiting to `/api/stats`.

The site is intentionally designed so more platform adapters can be added without changing the visual layer.
