import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const PORT = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY || "";
const YOUTUBE_CHANNEL_ID = process.env.YOUTUBE_CHANNEL_ID || ""; // Put the channel ID here.
const SOUNDCLOUD_CLIENT_ID = process.env.SOUNDCLOUD_CLIENT_ID || "";
const SOUNDCLOUD_CLIENT_SECRET = process.env.SOUNDCLOUD_CLIENT_SECRET || "";

const VIDEO_IDS = ["swCF5DMFquE","T59z8NQ3OMA","2H3Ei5EPkFc"];
const SOUNDCLOUD_TRACK_URLS = [
  "https://soundcloud.com/wrealx/monalisa",
  "https://soundcloud.com/wrealx/photo",
  "https://soundcloud.com/wrealx/hurry-up"
];

let cache = { at: 0, data: null };
const CACHE_MS = 5 * 60 * 1000;

function safeNum(x){ return x == null ? null : Number(x); }

async function youtubeStats(){
  if(!YOUTUBE_API_KEY || !YOUTUBE_CHANNEL_ID) return null;
  const url = new URL("https://www.googleapis.com/youtube/v3/channels");
  url.searchParams.set("part","statistics");
  url.searchParams.set("id",YOUTUBE_CHANNEL_ID);
  url.searchParams.set("key",YOUTUBE_API_KEY);

  const r = await fetch(url);
  if(!r.ok) throw new Error(`YouTube channel API: ${r.status}`);
  const j = await r.json();
  const s = j.items?.[0]?.statistics;
  if(!s) return null;

  const vurl = new URL("https://www.googleapis.com/youtube/v3/videos");
  vurl.searchParams.set("part","statistics");
  vurl.searchParams.set("id",VIDEO_IDS.join(","));
  vurl.searchParams.set("key",YOUTUBE_API_KEY);
  const vr = await fetch(vurl);
  if(!vr.ok) throw new Error(`YouTube videos API: ${vr.status}`);
  const vj = await vr.json();

  const videosById = {};
  for(const item of (vj.items || [])){
    videosById[item.id] = safeNum(item.statistics?.viewCount);
  }

  return {
    subscribers: safeNum(s.subscriberCount),
    views: safeNum(s.viewCount),
    videos: safeNum(s.videoCount),
    videosById
  };
}

async function soundcloudToken(){
  if(!SOUNDCLOUD_CLIENT_ID || !SOUNDCLOUD_CLIENT_SECRET) return null;
  const basic = Buffer.from(`${SOUNDCLOUD_CLIENT_ID}:${SOUNDCLOUD_CLIENT_SECRET}`).toString("base64");
  const r = await fetch("https://secure.soundcloud.com/oauth/token",{
    method:"POST",
    headers:{
      "accept":"application/json; charset=utf-8",
      "content-type":"application/x-www-form-urlencoded",
      "authorization":`Basic ${basic}`
    },
    body:"grant_type=client_credentials"
  });
  if(!r.ok) throw new Error(`SoundCloud token: ${r.status}`);
  const j = await r.json();
  return j.access_token;
}

async function soundcloudStats(){
  const token = await soundcloudToken();
  if(!token) return null;

  let totalPlaybackCount = 0;
  const tracks = [];

  for(const sourceUrl of SOUNDCLOUD_TRACK_URLS){
    const u = new URL("https://api.soundcloud.com/resolve");
    u.searchParams.set("url", sourceUrl);
    const r = await fetch(u,{
      headers:{
        "accept":"application/json; charset=utf-8",
        "authorization":`OAuth ${token}`
      }
    });
    if(!r.ok) continue;
    const t = await r.json();
    const plays = safeNum(t.playback_count);
    if(plays != null) totalPlaybackCount += plays;
    tracks.push({title:t.title || sourceUrl, playbackCount:plays});
  }

  return { totalPlaybackCount, tracks };
}

app.get("/api/stats", async (_req,res)=>{
  try{
    if(cache.data && Date.now()-cache.at < CACHE_MS) return res.json(cache.data);
    const [youtube, soundcloud] = await Promise.all([
      youtubeStats().catch(()=>null),
      soundcloudStats().catch(()=>null)
    ]);
    const data = {
      updatedAt: new Date().toISOString(),
      youtube,
      soundcloud
    };
    cache = {at:Date.now(), data};
    res.json(data);
  }catch(e){
    res.status(500).json({error:"Unable to load live stats"});
  }
});

app.use(express.static(path.join(__dirname,"public")));

app.get("*",(_req,res)=>{
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`Wreal X site running on http://localhost:${PORT}`));
